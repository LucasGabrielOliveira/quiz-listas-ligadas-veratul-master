# Caelum-CS14

Projeto desenvolvido como parte do treinamento CS-14 da Caelum.<br/>
O projeto tem o objetivo de demonstrar e reproduzir o fincionamento das estruturas de dados usando para isto a linguagem de programação Java.<br/>

Algumas das estruturas utilizadas no projeto:<br/>
* Vetores
* Listas Ligadas
* Pilhas
* Filas
* Tabelas de Espalhamento
* Mapas
