package br.com.caelum.ed.objetos.Disciplina;
import br.com.caelum.ed.objetos.Disciplina;

TesteListaDisciplina = new Disciplina();

}
